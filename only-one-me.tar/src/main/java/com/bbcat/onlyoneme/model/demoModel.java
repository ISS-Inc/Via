package com.bbcat.onlyoneme.model;

/**
 * @author: Ethan
 * @description:
 * @date:2019/5/31
 **/
public class demoModel {
}
