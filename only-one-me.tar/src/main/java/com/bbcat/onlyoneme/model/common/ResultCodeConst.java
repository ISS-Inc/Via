package com.bbcat.onlyoneme.model.common;

/**
 * @author: Ethan
 * @description:
 * @date:2019/2/20
 **/
public class ResultCodeConst {
    public final static int SUCCEED_CODE=200;
    public final static int FAILLING_CODE=400;
    public final static int LOGIN_FAILLING_CODE=401;
    public final static int TIMEOUT_CODE=408;
    public final static int NOTDATA_CODE=204;
}
