package com.bbcat.onlyoneme.model.common;


import java.util.Objects;

/**
 * @author: Ethan
 * @description:
 * @date:2019/2/20
 **/
public class Result<T> {

    private final static Result<?> EMPTY = new Result<>();

    private T data;

    /**
     * 错误信息
     */
    private String msg;
    /**
     * 状态 1成功 其它失败，失败需要返回msg
     */
    private int code;

    /**
     * 布尔值
     */
    private boolean flag = false;

    public boolean isFlag() {
        return flag;
    }

    public void setFlag(boolean flag) {
        this.flag = flag;
    }

    public String getFlag_value() {
        return flag_value;
    }

    public void setFlag_value(String flag_value) {
        this.flag_value = flag_value;
    }

    /**
     * 布尔描述
     */
    private String flag_value;



    public T getData() {
        return data;
    }

    public String getMsg() {
        return msg;
    }

    public int getCode() {
        return code;
    }





    private Result() {
        this.data = null;
    }

    private Result(String message, int code) {
        this.msg = message;
        this.code = code;
    }

    private Result(T data, int code) {
        this.data = data;
        this.code = code;
        if(code==200){
            this.msg="ok";
        }else {
            this.msg="exceptions";
        }
    }

    /**
     *
     * 功能描述: 创建一个空Result类
     * @auther: ethan
     * @date: 2019/02/20
     */
    public static <T> Result<T> empty() {
        @SuppressWarnings("unchecked")
        Result<T> t = (Result<T>) EMPTY;
        return t;
    }

    /**
     *
     * 功能描述: 生成一个成功状态Result类
     * @auther: ethan
     * @param: Data
     * @return: Result<T>
     * @date: 2019/02/20
     */
    public static <T> Result<T> success(T data) {
        return new Result<>(data, ResultCodeConst.SUCCEED_CODE);
    }

    /**
     *
     * 功能描述: 生成一个失败Result类
     * @auther: ethan
     * @param: 返回的错误信息
     * @return: Result<T>
     * @date: 2019/02/20
     */
    public static <T> Result<T> fail(String message) {
        return new Result<>(message, ResultCodeConst.FAILLING_CODE);
    }
    /**
     *
     * 功能描述: 生成一个失败Result类
     * @auther: ethan
     * @param: 返回的错误信息
     * @return: Result<T>
     * @date: 2019/02/20
     */
    public static <T> Result<T> relogin() {
        return new Result<>("请重新登录", ResultCodeConst.LOGIN_FAILLING_CODE);
    }
    /**
     *
     * 功能描述: 设置跳转地址
     * @auther: ethan
     * @param: 跳转地址
     * @return: Result<T>
     * @date: 2019/02/20
     */
    public <T> Result<T> setFlag(String url) {
        this.flag = true;
        this.flag_value = url;
        return (Result<T>) this;
    }

    /**
     *
     * 功能描述: 设置失败状态跳转地址
     * @auther: ethan
     * @param: 跳转地址
     * @return: Result<T>
     * @date: 2019/02/20
     */
    public <T> Result<T> orFailFlag(String url) {
        if (code == 201) {
            return (Result<T>) this;
        }
        this.flag = true;
        this.flag_value = url;
        return (Result<T>) this;
    }

    /**
     *
     * 功能描述: 判断是否传入值是否为空,非空则返回值，为空则返回失败信息
     * @auther: ethan
     * @param: 返回的错误信息
     * @return: Result<T>
     * @date: 2019/02/20
     */
    public <T> Result<T> orNotata(String message) {
        if (null != data&&!data.toString().equals("[]")) {
            return (Result<T>) this;
        } else {
            this.msg = message;
            this.code = ResultCodeConst.NOTDATA_CODE;
            return (Result<T>) this;
        }

    }

    @Override
    public int hashCode() {
        return Objects.hashCode(data);
    }


    @Override
    public String toString() {
        return data != null
                ? String.format("result[%s]", data)
                : "result.empty";
    }
}
