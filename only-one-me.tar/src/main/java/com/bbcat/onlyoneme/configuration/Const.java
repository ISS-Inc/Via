package com.bbcat.onlyoneme.configuration;

/**
 * @author: Ethan
 * @description:
 * @date:2019/5/31
 **/
public class Const {
    protected  final String PACKAGE_NAME="com.bcat.service";
}
