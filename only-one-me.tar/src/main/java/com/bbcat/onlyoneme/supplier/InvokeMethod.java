package com.bbcat.onlyoneme.supplier;


import com.bbcat.onlyoneme.core.ClassList;
import com.bbcat.onlyoneme.configuration.SpringUtil;
import com.bbcat.onlyoneme.model.common.Result;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class InvokeMethod {

    public static Object invokeing(Map<String, String[]> parameters, String methodName) {

        for (ClassList cla : ClassList.classLists) {
            for (Method method : cla.getMethods()
            ) {
                if (method.getName().equals(methodName)) {
                    try {
                        Map<String, String> paraHash = new HashMap<>();
                        Set<String> keys = parameters.keySet();
                        for (String keyname : keys ) {
                            paraHash.put(keyname, parameters.get(keyname)[0]);
                        }
                       Class Service= Class.forName(cla.getClassName());

                        Method methodService=Service.getMethod(methodName,paraHash.getClass());

                        return methodService.invoke(SpringUtil.getBean(Service), paraHash);
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (InvocationTargetException e) {
                        e.printStackTrace();
                    } catch (NoSuchMethodException e) {
                        e.printStackTrace();
                    }


                }
            }
        }
        return Result.fail("Error:The requested route you requested could not be found!");
    }
}
