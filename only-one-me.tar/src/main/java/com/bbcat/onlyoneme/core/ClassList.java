package com.bbcat.onlyoneme.core;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public class ClassList {
    private String className;

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getClassShortName() {
        return classShortName;
    }

    public void setClassShortName(String classShortName) {
        this.classShortName = classShortName;
    }

    public Method[] getMethods() {
        return methods;
    }

    public void setMethods(Method[] methods) {
        this.methods = methods;
    }

    private String classShortName;
    private Method [] methods;
    public static List<ClassList> classLists =new ArrayList<>();
}
