package com.bbcat.onlyoneme.core;
/**
 * @author: Ethan
 * @version: v1.0
 * @description: 总入口
 * @date: 12.20
 * */

import com.bbcat.onlyoneme.supplier.InvokeMethod;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
public class CenterHandler {
    @RequestMapping("/Api/{method}")
    public Object Api(@PathVariable String method, HttpServletRequest request){
        Map<String, String[]> requestParameterMap=request.getParameterMap();

        return InvokeMethod.invokeing(requestParameterMap,method);
    }
}
