package com.bbcat.onlyoneme.service.impl;

import com.bbcat.onlyoneme.model.common.Result;
import com.bbcat.onlyoneme.service.demoService;
import org.springframework.stereotype.Service;

import java.util.HashMap;

/**
 * @author: Ethan
 * @description:
 * @date:2019/5/31
 **/
@Service
public class demoServiceWorker implements demoService {
    @Override   //方法名注意不要重複，因為這是用作路由，重複了你就完蛋了
                //但是我建議你新增就寫add開頭，以此類推，不要問為什麼，因為這是我瞎說的
    public Result addDemo(HashMap map) {
        return Result.success("成功示範，這裡這裡可以放各種類型的對象，如果你只寫一個字也可以")
                .orNotata("如果前面存放的對象是空的，這裡面是你將要提示的語言，你可以說：小子，這裡沒有數據");
//        return Result.relogin();
//        return Result.fail("小子，這裡表示你操作失敗了");
    }
}
