package com.bbcat.onlyoneme.service;

import com.bbcat.onlyoneme.model.common.Result;

import java.util.HashMap;

/**
 * @author: Ethan
 * @description:
 * @date:2019/5/31
 **/
public interface demoService {
    /**
     * @author: Ethan
     * @description: 參數必須是HashMap
     * @date:2019/5/31
     **/
    Result addDemo(HashMap map);
}
